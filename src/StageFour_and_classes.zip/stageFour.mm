/*
 *  stageFour.mm
 *  AIDawn
 *
 *  Created by CORE LABS on 3/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "stageFour.h"

StageFour::StageFour(){
	//colors
	textColor = 0xFFDE00;
	buttonColor = 0xFFDE00;
	
	//font
    tempesta.loadFont("pf_tempesta_seven.ttf", 6);
	frabk.loadFont("pf_tempesta_seven.ttf", 12);
	
	strcpy(sendStatusString, "No information about sent score");
	
	
	//--------PETICION DEL XML DE LA BASE DE DATOS
	rawXML.openFromURL("http://corelabs.cn/interactive/AIDawn/mySettings.xml"); 
	XML.loadFromBuffer(string(rawXML.read()));

		
}


void StageFour::draw(){
	//-------- TEXT
	ofSetColor(textColor);
	
	frabk.drawString("HALL OF FAME\n", 10-ofGetWidth()/2,TEXT_INTRO_Y+10-ofGetHeight()/2);
	
	//--------PARSEO Y DRAW DEL XML 
	//push into the first tag and make it the "root"
	XML.pushTag("entries", 0);
	for(int i = 0; i < 10; i++){
		
		//push into the second tree tag and make it the "root"
		XML.pushTag("entry", i);
		listrank = XML.getValue("id", 0, 0);
		sprintf(rankScore, "Rank %d ",listrank);
		tempesta.drawString(rankScore, 10-ofGetWidth()/2,TEXT_INTRO_Y+80-ofGetHeight()/2+i*10);

		listname = XML.getValue("titulo", "", 0);		
		tempesta.drawString(listname,50-ofGetWidth()/2,TEXT_INTRO_Y+80-ofGetHeight()/2+i*10);

		listtime = XML.getValue("contenido", 0, 0);
		sprintf(timeScore, "Time %f\n ",listtime);
		tempesta.drawString(timeScore, 100-ofGetWidth()/2,TEXT_INTRO_Y+80-ofGetHeight()/2+i*10);

		XML.popTag();
		
	}
	//-------- FIN DEL PARSEO Y DRAW DEL XML 
	
	
	//--------- RESTART BUTTON
	ofSetColor(buttonColor);
	ofRect(OK_POS_X-ofGetWidth()/2, OK_POS_Y-ofGetHeight()/2, OK_WITH, OK_HEIGHT);
	ofSetColor(0, 0, 0);
	tempesta.drawString("RESTART", OK_POS_X+3-ofGetWidth()/2,OK_POS_Y+25-ofGetHeight()/2);
}

void StageFour::update(){


}

bool StageFour::checkHit(int x, int y){
	return false;
}



void StageFour::reset(){

}


void StageFour::close(){
//	freeCircles();
}

void StageFour::setStatusText(char text[255]){
	strcpy(sendStatusString, text);
}

